# Učitavanje slike
library(tiff)
A <- readTIFF('F:\\Education\\RADOVI\\Filter\\Salt & Papper Noise\\Yoda\\05.tiff')

# Prikaz originalne slike
plot(as.raster(A))

# Kopiranje slike u novu matricu
B <- A

# Dimenzije slike
dim_A <- dim(A)

# Filtriranje šuma (Salt & Pepper)
for (k in 1:dim_A[3]) {
  for (i in 2:dim_A[1]) {
    for (j in 1:dim_A[2]) {
      if (A[i,j,k] > 0.996) {
        B[i,j,k] <- A[i-1,j,k]
      } else if (A[i,j,k] < 0.008) {
        B[i,j,k] <- A[i-1,j,k]
      }
    }
  }
}

# Prikaz B slike
plot(as.raster(B))

C <- B
dim_B <- dim(B)

for (l in 1:dim_B[3]) {
  for (o in 1:dim_B[1]) {
    for (p in 2:dim_B[2]) {
      if (B[o,p,l] > 0.996) {
        C[o,p,l] <- B[o,p-1,l]
      } else if (B[o,p,l] < 0.008) {
        C[o,p,l] <- B[o,p-1,l]
      }
    }
  }
}

# Prikaz C slike
plot(as.raster(C))

D <- C
dim_C <- dim(C)

for (d in 1:dim_C[3]) {
  for (a in 1:dim_C[1]) {
    for (s in 1:(dim_C[2]-1)) {
      if (C[a,s,d] > 0.996) {
        D[a,s,d] <- C[a,s+1,d]
      } else if (C[a,s,d] < 0.008) {
        D[a,s,d] <- C[a,s+1,d]
      }
    }
  }
}

# Prikaz D slike
plot(as.raster(D))

E <- D
dim_D <- dim(D)

for (e in 1:dim_D[3]) {
  for (q in 1:(dim_D[1]-1)) {
    for (w in 1:dim_D[2]) {
      if (D[q,w,e] > 0.996) {
        E[q,w,e] <- D[q+1,w,e]
      } else if (D[q,w,e] < 0.008) {
        E[q,w,e] <- D[q+1,w,e]
      }
    }
  }
}

# Prikaz E slike
plot(as.raster(E))

F <- E
dim_E <- dim(E)

for (c in 1:dim_E[3]) {
  for (z in 2:dim_E[1]) {
    for (x in 2:dim_E[2]) {
      if (E[z,x,c] > 0.996) {
        F[z,x,c] <- E[z-1,x-1,c]
      } else if (E[z,x,c] < 0.008) {
        F[z,x,c] <- E[z-1,x-1,c]
      }
    }
  }
}

# Prikaz F slike
plot(as.raster(F))

G <- F
dim_F <- dim(F)

for (n in 1:dim_F[3]) {
  for (v in 1:(dim_F[1]-1)) {
    for (b in 1:(dim_F[2]-1)) {
      if (F[v,b,n] > 0.996) {
        G[v,b,n] <- F[v+1,b+1,n]
      } else if (F[v,b,n] < 0.008) {
        G[v,b,n] <- F[v+1,b+1,n]
      }
    }
  }
}

# Prikaz G slike
plot(as.raster(G))

H <- G
dim_G <- dim(G)

for (h in 1:dim_G[3]) {
  for (f in 2:dim_G[1]) {
    for (g in 1:(dim_G[2]-1)) {
      if (G[f,g,h] > 0.996) {
        H[f,g,h] <- G[f-1,g+1,h]
      } else if (G[f,g,h] < 0.008) {
        H[f,g,h] <- G[f-1,g+1,h]
      }
    }
  }
}

# Prikaz H slike
plot(as.raster(H))

I <- H
dim_H <- dim(H)

for (r in 1:dim_H[3]) {
  for (t in 1:(dim_H[1]-1)) {
    for (m in 2:dim_H[2]) {
      if (H[t,m,r] > 0.996) {
        I[t,m,r] <- H[t+1,m-1,r]
      } else if (H[t,m,r] < 0.008) {
        I[t,m,r] <- H[t+1,m-1,r]
      }
    }
  }
}


# Snimanje filtrirane slike
writeTIFF(I, 'C:\\Users\\Bato\\Desktop\\konacnoR.png')

# Prikaz filtrirane slike
plot(as.raster(I))

